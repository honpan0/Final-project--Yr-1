#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define MAX_TRIES 10 // 最大的猜測次數
#define NUM_SIZE 4 // 數字的個數
#define NUM_MIN 1 // 數字的最小值
#define NUM_MAX 6 // 數字的最大值

// 宣告一些全域變量，用於存儲電腦的數字、玩家的輸入和提示
int numbers[NUM_SIZE];
int input[NUM_SIZE];
char hints[NUM_SIZE];

// 宣告一些函數原型，用於實現遊戲的邏輯
void generate_random_numbers();  // 生成隨機數字
int read_input(); // 讀取玩家的輸入，並檢查是否合法，返回0或1
void compare_numbers(); // 比較玩家的輸入和電腦的數字，並給出提示
int is_game_over(); // 判斷遊戲是否結束，並返回結果，0表示遊戲繼續，1表示玩家贏了，-1表示玩家輸了



int end(int a);
void endding(void);
void rule(void);
int tries = 0;
int story(void);



int main()
{
    printf("歡迎來到珠璣妙算遊戲！\n\n");
    while (1)
    {
        generate_random_numbers();
        int aws;
        int choose;
        int tries = 0;
        int result = 0;
        int cho = 0;
        int  time1;
        int ren[4];
        int ju;
        srand(time(NULL));
        printf("請問是否準備好開始遊戲(開始：按1/故事：按2)：");
        scanf("%d", &aws);

        if (aws == 1)
        {
            system("clear");
            rule();
            while (1) {
                // 增加猜測次數
                tries++;
                // 提示玩家輸入
                printf("第%d次猜測：", tries);
                // 讀取玩家的輸入，並檢查是否合法


                int valid = read_input();
                // 如果不合法，就提示玩家重新輸入，並跳過本次循環
                if (!valid) {
                    printf("輸入無效，請重新輸入。\n");
                    tries--;
                    continue;
                }





                int black = 0;
                compare_numbers(&black);
                // 輸出提示
                printf("提示：");
                for(int i=0;i<4;i++)
                {
                    
                    int k=rand()%4;
                     ren[i]=k;
                     for(int j=0;j<i;j++)
                     {
                        if( ren[i]== ren[j])
                        {
                          i--;
                        }
                     }
                       
                    
                }
                for (int times=0;times<4;times++)
                { 
                  int a=ren[times];
                  printf("%c ", hints[a]);
                }
                printf("\n");
                
                // 判斷遊戲是否結束，調用 is_game_over 函數時，傳遞 black 和 tries 的值
                result = is_game_over(&black, tries);

                if (result == 1)
                {
                    cho = end(1);
                    system("clear");
                    if (cho == 0)
                       { 
                           endding();
                           printf("是否返回主頁面(是：請打1,否：請打0)：");
                           scanf("%d",&ju);
                           if(ju==1)
                           {
                               system("clear");
                               printf("歡迎來到珠璣妙算遊戲！\n\n");
                               break;
                           }
                           if(ju==0)
                           {
                           
                             exit(0);
                           }
                       }
                        
                    if (cho == 1)
                    {
                        tries = 0;
                        rule();
                    }


                }
                else if (result == -1)
                {
                    cho = end(0);
                    system("clear");
                    if (cho == 0)
                    {
                        endding();
                        printf("是否返回主頁面(是：請打1,否：請打0)：");
                           scanf("%d",&ju);
                           if(ju==1)
                           {
                               system("clear");
                               printf("歡迎來到珠璣妙算遊戲！\n\n");
                               break;
                           }
                           if(ju==0)
                           {
                           
                             exit(0);
                           }
                
                    }
                    if (cho == 1)
                    {
                        tries = 0;
                        rule();
                    }

                }


            }




        }
        
        else if(aws==2)
        {
            choose=story();
            if(choose==1)
            {
            system("clear");
            printf("歡迎來到珠璣妙算遊戲！\n\n");
            
            }
            
        }
        else if (aws != ( 1||2))
            printf("\n輸入無效，請重新輸入。\n");
        
    }
    return 0;

}

// 生成隨機數字的函數實現
void generate_random_numbers()
{
    srand(time(NULL));
    for (int i = 0; i < NUM_SIZE; i++) {
        // 生成一個NUM_MIN到NUM_MAX的隨機數
        int n = rand() % (NUM_MAX - NUM_MIN + 1) + NUM_MIN;
        // 檢查是否和之前的數字重複，如果是，就重新生成
        for (int j = 0; j < i; j++) {
            if (n == numbers[j]) {
                n = rand() % (NUM_MAX - NUM_MIN + 1) + NUM_MIN;
                j = -1; // 重置j，重新檢查
            }
        }
        // 把生成的數字存入數組
        numbers[i] = n;
    }
}

// 讀取玩家的輸入的函數實現
int read_input()
{
    int  inppt[4];
    int a;
    scanf("%d %d %d %d",&inppt[0], &inppt[1], &inppt[2], &inppt[3]);
    getchar;
    // 用一個循環來讀取四個數字
    for (int i = 0; i < NUM_SIZE; i++) {
        if ((!inppt[i] &&1)&&tries<MAX_TRIES) {
            return 0;
        }
        // 檢查是否在NUM_MIN到NUM_MAX的範圍內，如果不是，就返回0，表示輸入無效
        if ((inppt[i] <=NUM_MIN-1 || inppt[i] >= NUM_MAX+1)&&tries<MAX_TRIES) {
           
            return 0;
            
        }
        // 檢查是否和之前的數字重複，如果是，就返回0，表示輸入無效
        if(tries<MAX_TRIES)
        {
            for (int j = 0; j < i; j++)
            {
                if (inppt[i] == input[j]) 
                {
                    
                    return 0;
                }
            }
        }
        // 把讀取的數字存入數組
        input[i] = inppt[i];
    }
    // 如果沒有問題，就返回1，表示輸入有效
    return 1;
}

void compare_numbers(int* black) // 用指針參數來修改黑子的數量
{
    // 初始化黑子和白子的數量為0
    *black = 0; // 用*來訪問指針指向的變數
    int white = 0;
    // 用一個循環來遍歷四個數字
    for (int i = 0; i < NUM_SIZE; i++)
    {
        // 如果數字和位置都對，就增加黑子的數量，並把提示設為B
        if (input[i] == numbers[i])
        {
            (*black)++;
            // 用*來訪問指針指向的變數
            hints[i] = 'B';
        }
        else
        {
            // 否則，就把提示設為-
            hints[i] = '-';
        }
    }

    for (int i = 0; i < NUM_SIZE; i++)
    {
        for (int j = 0; j < NUM_SIZE; j++)
        {
            // 如果數字對但位置不對，並且提示還沒有設為B，就增加白子的數量，並把提示設為W
            if (input[i] == numbers[j] && hints[j] != 'B')
            {
                white++;
                hints[j] = 'W';
                break; // 跳出內層循環，避免重複計算
            }
        }
    }
    // 如果黑子的數量等於數字的個數，就表示玩家猜對了，把提示設為BBBB
    if (*black == NUM_SIZE) // 用*來訪問指針指向的變數
    {
        for (int i = 0; i < NUM_SIZE; i++)
        {
            hints[i] = 'B';
        }
    }
}

// 判斷遊戲是否結束的函數實現
int is_game_over(int *black, int tries)
{
    // 如果黑子的數量等於數字的個數，就表示玩家猜對了
    if (*black == NUM_SIZE)
    {
        return 1;
    }
    // 如果猜測次數超過了最大次數，就表示玩家用完了機會
    if (tries == MAX_TRIES)
    {
        return -1;
    }
    // 否則，就表示遊戲還沒有結束
    return 0;
}
int end(int a)
{
    int cho;
    if (a == 1)
    {
        printf("恭喜你，你猜對了！\n");
        printf("數字是：");
        for (int i = 0; i < NUM_SIZE; i++)
        {
            printf("%d ", numbers[i]);
        }
       
    }
    else if(a==0)
    {
            printf("很遺憾，你沒有猜對。\n電腦的數字是：");
        for (int i = 0; i < NUM_SIZE; i++)
        {
            printf("%d ", numbers[i]);
        }
    }
    while(1)
    {
    printf("\n");
    printf("是否還要再玩一次(1/0)：");
    scanf("%d", &cho);
    
    if (cho == 0)
        return 0;
    else if (cho == 1)
        return 1;
    else if (cho != (0 || 1))
      printf("\n輸入無效，請重新輸入。\n");
    }
}
void endding(void)
{
    system("clear");
    printf("感謝你們的遊玩\n");
    printf("***你們的支持是我們的最大動力***\n");
}
void rule(void)
{
    printf("電腦已經隨機生成了四個不重複的數字（%d-%d），你有%d次機會猜出它們。\n", NUM_MIN, NUM_MAX, MAX_TRIES);
    printf("每次猜測後，電腦會給出提示：B代表黑子，表示數字和位置都對；W代表白子，表示數字對但位置不對；-代表沒有猜中任何數字。\n");
    printf("請輸入你的猜測，並用空格分隔每個數字，例如：1 2 3 4\n");
}
int story(void)
{
    system("clear");
    int Exit;
    printf("在遙遠的未來，地球大氣層的臭氧層逐漸被破壞，使得地球陷入了無法居住的危機。\n");
           printf("為了拯救地球，科學家發現了一個神秘行星，擁有著能夠解開地球毀滅密碼的能力。\n");
           printf("這顆行星以六個顏色作為標誌，只有找到並解開這六個顏色的密碼，才能啟動行星的力量，拯救地球。\n");
           printf("勇敢的太空探險家們啟動了尋找行星的任務。他們進入了星際，穿過無數的星系，卻在一片神秘的星雲中迷失了方向。\n");
           printf("在一次深夜的探索中，他們意外發現了解開密碼的線索，原來密碼是由六個不同星系的特殊光之頻率組成的，\n");
           printf("這些特殊的光之頻率分別代表著紅色、藍色、綠色、黃色、橙色和紫色。\n");
           printf("經歷了無數的艱辛和危險，最終他們找到了這六個星系，解開了光之頻率所代表的密碼。當他們回到地球時，將這六個頻率輸入到尋找\n");
    printf("返回請按1：");
    scanf("%d",&Exit);
    if(Exit==1)
      return 1;
    
}



